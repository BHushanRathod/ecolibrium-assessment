from django.apps import AppConfig


class TaskBasedExecConfig(AppConfig):
    name = 'task_based_app'
